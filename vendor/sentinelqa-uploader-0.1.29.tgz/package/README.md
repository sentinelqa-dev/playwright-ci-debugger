# @sentinelqa/uploader

Low-level Sentinel uploader CLI for Playwright artifacts and hosted Sentinel run links.

`@sentinelqa/playwright-reporter` is the recommended integration for most teams.
Use this package only if you need direct CLI control or custom wrapper behavior.

## Install

```bash
npm i -D @sentinelqa/uploader
```

## Usage

```bash
sentinelqa upload --playwright-json-path test-results/report.json
```

Direct upload after tests already ran:

```bash
npx @sentinelqa/uploader upload --playwright-json-path test-results/report.json
```

Universal wrapper for custom commands:

```bash
npx @sentinelqa/uploader run -- <your test command>
```

## Playwright Failure Context Capture (DOM + Mutation Signals)

Add this helper to capture DOM target state and mutation signals on failures:

```ts
import { sentinelCaptureFailureContext } from "@sentinelqa/uploader/playwright";

test.afterEach(async ({ page }, testInfo) => {
  await sentinelCaptureFailureContext(page, testInfo);
});
```

This writes `dom-capture-*.json` to `test-results/sentinel-dom/` and attaches it to the Playwright report so the uploader can associate it with the correct test.

## Environment Variables

- `SENTINEL_TOKEN` (optional; required only for uploading into a specific Sentinel workspace)
- `SENTINEL_TEST_EXIT_CODE` (optional; set automatically by the wrapper)
- `SENTINEL_REQUEST_TIMEOUT_MS` (optional; override API request timeout, default `45000`)
- `SENTINEL_UPLOAD_TIMEOUT_MS` (optional; override artifact upload timeout, default `120000`)

## Optional: BYO S3 (Advanced)

Set these to upload directly to your own bucket:

- `SENTINEL_S3_ENDPOINT` (optional for AWS)
- `SENTINEL_S3_REGION`
- `SENTINEL_S3_BUCKET`
- `SENTINEL_S3_PREFIX` (optional)
- `SENTINEL_S3_ACCESS_KEY_ID`
- `SENTINEL_S3_SECRET_ACCESS_KEY`

## Troubleshooting

**Missing artifacts**
- Ensure Playwright outputs are present:
  - a Playwright JSON report
  - `playwright-report/`
  - `test-results/`

**401 Unauthorized**
- Check `SENTINEL_TOKEN` and project permissions if you are uploading into a workspace.

**Custom app URL override**
- Custom `SENTINEL_URL` or `APP_URL` values are not supported.
- Sentinel uploads always target `https://app.sentinelqa.com`.

**No CI metadata**
- The uploader detects GitLab, GitHub, CircleCI, or local git metadata.

**No failed tests**
- Ensure `@playwright/test` is installed and the JSON reporter is enabled.

**BYO uploads failing**
- Verify `SENTINEL_S3_*` values and permissions.
